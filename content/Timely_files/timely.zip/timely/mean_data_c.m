function [e_mu, e_sigma]=mean_data_c(independent_variable,proportion_of_responces)
% Calculates the mean of the distribution underlying the proportion of responses
% obtained -for example- in a TOJ task. It first calculates the inverse of
% the cumulative (the differential) of the responce proportion and then
% makes a weighted sum of the independent values in the middle of the
% intervals (for which the differentials has been calculated).
% It can be used to compare the estimate of the PSE computed using a
% symmetric psychometric curve (which corresponds to the median of the
% cumulative distribution).
%Usage:
% [e_mu, e_sigma]=mean_data_c(independent_variable,proportion_of_responces);
% 
% inputs: two vectors with the same number of elements
%  - independent_variable     SOAs in ta TOJ task   
%  - proportion_of_responces  proportion of responses for each SOA
%  *NB* The proportion of responses should be larger for more positive SOAs
%  *NB* It is assumed that the proportion of responses is at ceiling for
%  extreme SOAs
%
% outputs: two values
%  - e_mu         estimate of the mean of the underlying distribution
%  - e_sigma      estimate of the standard deviation of the underlying distribution
%
% Examples:
% independent_variable     =[-240 -200 -160 -120  -80  -40    0  40  80 120 160 200 240];
% proportion_of_responces  =[   0    0    0   .1   .5   .7   .8  .9   1   1   1   1  1 ];
% [e_mu, e_sigma]=mean_data_c(independent_variable,proportion_of_responces)
% 
% >>e_mu =
% 
%    -60
% 
% 
% >>e_sigma =
% 
%    59.3296
% 
% mu=rand(1)*100-50;
% sigma=rand(1)*100+10;
% x=-200:50:200;
% sy=normcdf(x,mu,sigma);
% [e_mu,e_sigma]=mean_data_c(x,sy);
% clf
% hold on
% plot(x,sy,'.k');
% plot(mu,.5,'*r')
% plot(e_mu,.5,'ob')
% plot([mu mu+sigma],[.5 .84],'r')
% plot([mu e_mu+e_sigma],[.5 .84],'b')
% legend({'datapoint','real mu','estimated mu','real sigma','estimated sigma'})
%
% Created by Massimiliano Di Luca max@tuebingen.mpg.de, Tuebgingen 7/10/2007
% m.diluca@bham.ac.uk 12/06/2012 changed extreme values from +/- mean of the interval to +/- last interval
% m.diluca@bham.ac.uk 24/07/2012 cleaned up instructions and added plot function example for Prof Ulrik

%makes input vectors to be all row vectors
independent_variable=reshape(independent_variable,1,max(size(independent_variable)));
proportion_of_responces=reshape(proportion_of_responces,1,max(size(proportion_of_responces)));

[independent_variable,order]=sort(independent_variable);
proportion_of_responces=proportion_of_responces(order);

%calculates the half point between each pair of independent values
independent_variable_middle=independent_variable(1:end-1)+diff(independent_variable)/2;

%add two values of independent_variable at the beginning and end
independent_variable_middle=[2*independent_variable(1)-independent_variable(2) independent_variable_middle 2*independent_variable(end)-independent_variable(end-1)];

%calculates the difference of responces at each successive pair of soas
prop=diff([0 proportion_of_responces 1]);

%%normalizes the probability (area under the graph) to one
%not needed if last answer is 1!!%%prop=prop/sum(prop);

%weight each independent_variable at half point for the corresponding difference in responces
e_mu=sum(prop.*independent_variable_middle);

%weight the square differences between the half point and the mean
e_sigma=sqrt(sum(prop.*(independent_variable_middle-e_mu).^2));
