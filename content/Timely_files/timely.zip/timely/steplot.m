function steplot(varargin)
%STEBAR Standard error bar plot.
%   ERRORBAR(X,Y) plots the graph of vector X vs. mean of columns of vector Y with
%   error bars calculated as the standard error of the data Y for each column.
%   The vector X and the column Y must have the same number of columns.
%
%
%
%
%
%
% max di luca


col='k';

x=varargin{1};
y=varargin{2};
if nargin>2
col=varargin{3};
end

n = size(y,2);

if size(x,2)~=size(y,2)
  if size(x,1)~=size(y,2)
    error('MATLAB:errorbar:InputSizeMisMatch',...
        'X and Y must all be the same number of columns');
  else
      y=y';
  end
end


temphold=ishold;
plot(x,mean(y,1),['-' col 'o'],'LineWidth',2)
hold on
plot(repmat(x,2,1),[mean(y,1)-std(y,1)/sqrt(size(y,1)-1); mean(y,1)+std(y,1)/sqrt(size(y,1)-1)],['-' col ])
if temphold~=1
hold off;
end
maxis=axis;
try
    axis([min(x)-(max(x)-min(x))/10 max(x)+(max(x)-min(x))/10 maxis(3) maxis(4)]);
end