function analysis_training(name)




%directory='../prior av pilot 1/data/';%'./data';
directory='./data';

soa_resamp =[   -0.1700   -0.0900   -0.0500   -0.0250         0    0.0250    0.0500    0.0900    0.1700];

speaker=1;vibrator=2;light=3;
stimulus_appearing_first_with_positive_soa = speaker;

c='rgbrgb';
s='ooo***';



subjectcounter=0;

datarawa=[];
fils=dir([directory '/*'  name  '*_dat_t.txt']);
 try
        for n=1:size(fils,1)
            disp(['Trying: ' directory '/' fils(n).name])
            fid=fopen([directory '/' fils(n).name],'r');
            
            frewind(fid)
            disp(['Extracting data...']);
            [datarawp nc] = fscanf(fid,['%*s  %i %i %i %i    %f %i %f %i     %f %i     '  repmat(' %f',1,8+2)  ' '],[20, inf] );
            
            
            
            
            
            
            col_phase=1;
            col_block=2;
            col_trial=3;
            col_pair=4;
            
            col_soa=5;
            col_n_rep_stim=6;
            col_async=7;
            col_stimulus_type=8;
            col_rt=9;
            col_resp=10;
            %  signaltiming(1), signaltiming(2), signaltiming(3), signaltiming(4), signaltiming(5) , signaltiming(6) , signaltiming(7) , signaltiming(8) , signaltiming(9) , signaltiming(10) );
            
            
            
            
            
            fclose(fid)  ;
            datarawa=[datarawa; datarawp'];
        end
    catch
        fclose all
        lasterr
        disp(['File for subject '  char(filenames(subject))  ' does not exist or is not conform ...'])
    end
    
    dataraw=datarawa;

% dataraw(dataraw(:,6)>10,:)=[];

maxvi=max(.15,max(abs(dataraw(:,col_soa))))*1.1;%maximum soa to plot
soa_tested=(unique(dataraw(:,col_soa))');


n_rep_stims=unique(dataraw(:,col_n_rep_stim))';
asyncs=unique(dataraw(dataraw(:,col_n_rep_stim)~=0,col_async))';
stimulus_types=unique(dataraw(dataraw(:,col_n_rep_stim)~=0,col_stimulus_type))';
counter=0;
datafito=[0 0];
datafit0=0;
for n_rep_stim=n_rep_stims   %[0 2]%
    if n_rep_stim==0
        asyncsa=0;
        stimulus_typesa=1;
    else
        asyncsa=asyncs;
        stimulus_typesa=stimulus_types;
    end
    for stimulus_type=stimulus_typesa
        for async=asyncsa
            
            soacounter=1;
            datafit=[];
            %    data_binned=dataraw(dataraw(:,col_n_rep_stim)>0&dataraw(:,col_async)==async&dataraw(:,col_stimulus_type)==stimulus_type,:);
            data_binned=dataraw(dataraw(:,col_n_rep_stim)==n_rep_stim&dataraw(:,col_async)==async&dataraw(:,col_stimulus_type)==stimulus_type,:);
            
            for soa=soa_tested %+means l..s
                if stimulus_type ==1
                    data_binned_soa=data_binned(data_binned(:,col_soa)==soa,:);
                else
                    data_binned_soa=data_binned(data_binned(:,col_soa)==-soa,:);
                end
                trials=size(data_binned_soa,1);
                yes=mean(data_binned_soa(:,col_resp)~=stimulus_appearing_first_with_positive_soa);
                datafit(soacounter,:)=[soa yes trials];
                soacounter=soacounter+1;
            end
            hold on
            try
                
                %  pse=pfit(datafit,'no plot', 'shape', 'cumulative Gaussian', 'n_intervals', 1, 'runs', 2, 'sens', 0, 'verbose', 0,'cuts',[.25 .5 .75],'alpha_prior',' -gaussian -.03 .04','beta_limits',' 0.8 0.12');
                % datafit(:,2)=datafit(:,2).*    datafit(:,3);
                counter=counter+1;
             %   subplot(4,4,1+n_rep_stim*4+(find(stimulus_type==stimulus_typesa)-1)*2+(find(async==asyncsa)-1))
                title([int2str(n_rep_stim) ' ' num2str(async) ' ' int2str(stimulus_type)])
                hold on
                plot(datafit(:,1),datafit(:,2),['ob-'])
            
                axis([-.4 .4 0 1])%min(datafit(:,1)) max(datafit(:,1)) 0 1])
                
                
                
            catch
                
                msgstr = lasterr
                disp([{'IV' 'prop.resp' '#trials'}])
                disp(datafit)
            end
            
            %
            %         pss(condition,subjectcounter) = pse.thres(2);%  pse.thresholds.est(3)- pse.thresholds.est(2) wronganswers] ;
            %         jnd(condition,subjectcounter) = pse.thres(3)- pse.thres(2);% wronganswers] ;
            %
            %
            %else
            %   error('not enough datapoint in the file')
        end
    end
end

