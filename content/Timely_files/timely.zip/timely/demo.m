%demo of fiio amplifier and testing device with LED and speaker
%shows 5 SOAs and requests space to continue after each of them
%turn up the volume all the way and turn on the amplifier (blue light)
%
%m.diluca@bham.ac.uk        12/2/2013

clear all
Fs=44100;
frequency =[3000 100];
duration=.2;    
aplitude = [.3           1 ];
    
delay =.5+[0 .5 ];    
beepit(frequency,delay,duration,aplitude,2,Fs,.01);    

clc;keyinteraction({'space'},[],1);

delay =.5+[.5 0];
beepit(frequency,delay,duration,aplitude,2,Fs,.01);

clc;keyinteraction({'space'},[],1);

delay =.5+[0 0.25];
beepit(frequency,delay,duration,aplitude,2,Fs,.01);

clc;keyinteraction({'space'},[],1); 

delay =.5+[0.25 0];
beepit(frequency,delay,duration,aplitude,2,Fs,.01);

clc;keyinteraction({'space'},[],1);

delay =.5+[0 0];
beepit(frequency,delay,duration,aplitude,2,Fs,.01);


clc;disp('demo ended')