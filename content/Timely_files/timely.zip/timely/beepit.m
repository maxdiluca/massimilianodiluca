function [ending,time]=beepit(varargin)

%
% uses sound to play a series of sinusoids with different delay
%
% Usage: beepit(signalfrequency,delay,duration,amplitude,totalduration,[Fs],[smoothingtime],[1])
%
% Example:
% 
% 
% Fs=44100;   
% f =1500;
% delay =[0.5 0.9];
% amp = [.1 1];
% 
% beepit(f,delay,.2,amp,2,Fs,.05)

% Input:
%   1- signalfrequency    Beginning frequency of the sinusoidal signal
%   2- delay         In seconds from time=0 to beginning of sinusoid; 0 asap (only 1 signal)
%   3- duration      Of the sinusoid only
%   4- amplitude     Amplitude of the sinusoid
%   5- totalduration [opt] Of the signal in seconds (including delay)
%   6- Fs            [opt] Sampling frequency (default 44100)
%   7- smoothingTime [opt] Rising and decaying time of the sinusoid (it's in seconds, but it defaults to 1 sample, does not increase sinusoid duration)
%
%
% Massimiliano Di Luca 09/22/06
% max 0102/2010 rehauled to use playrec
% max 08/02/2010 added check for ecape pressed in the main loop generating the buffer
% max 15/02/2010 added 12th parameter to define soa of noise added
% max & Tonja 05/03/2010 added 1/Fs to the totalduration, added a try/catch to the sum of the signal buffer with the total buffer
% max 18/05/2010 changed display of completed computation from percentage to number of channels
% max 17/06/2010 added GetSecs and latency to obtain playing time, added output argument
% max 23/06/2010 changed recording channels to 8
% max & Michael 17/07/2010 changed esc -> Escape
% Tonja 22/07/2010 "Escape" had changed back to "esc" for unknown reasons, I fixed it again.
% Tonja 23/07/2010 Conor needs "esc" and I need "Escape" for our programs to run. Jess and I decided to change it before each session.
% Max 23/12/2011 Adapted to the new setup in Frankland


tic
channels_used=2;
ending=false;

signalfrequency=varargin{1};

delay=varargin{2};


numbersignals=size(delay,1);

if max(size(delay,2))==1;
    delay=repmat(delay,numbersignals,channels_used);
end

duration=varargin{3};
if max(size(duration,2))==1;
    duration=repmat(duration,numbersignals,channels_used);
end


if min(size(signalfrequency))==1
    signalfrequency=repmat(signalfrequency,numbersignals,channels_used);
    
end
if size(duration,1)==1
    duration=repmat(duration,numbersignals,channels_used);
end

amplitude=varargin{4};
if varargin{5}>0
    durationtotal=varargin{5};
else
    durationtotal=max(max(delay))+.1;
end



if length(varargin)>=6&&varargin{6}~=1
    Fs=varargin{6};
else
    Fs=44100;
end


if length(varargin)>=7&&varargin{7}~=1
    duration_smoothing=abs(varargin{7});
else
    duration_smoothing=1/Fs;
end



noesc=[];


lenghtbuffer=floor(durationtotal*Fs);

buffer_complete=zeros(lenghtbuffer,channels_used);
buffer_one_signal=zeros(lenghtbuffer,1);
buffer_one_channel=zeros(lenghtbuffer,1);

initkeys=0;
try
    noesc=keyinteraction({'Escape'},[],-1);%checks whether esc has been pressed
    initkeys=1;
catch
    initkeys=-1;
end

for channel=1:2
    
    buffer_one_channel=buffer_one_channel*0;
    
    for signal=1:numbersignals
        
        if amplitude(signal,channel)>0
            
            buffer_one_signal=buffer_one_signal*0;
            
            time_vector=(1/Fs:1/Fs:(duration(signal,channel)));
            
            lenght_smoothing=floor(Fs*duration_smoothing);
            
            if lenght_smoothing>0
                modulation=time_vector*0+1;
                modulation(1:lenght_smoothing+1)=0:1/lenght_smoothing:1;
                modulation(end:-1:end-lenght_smoothing)=0:1/lenght_smoothing:1;
            else
                modulation=time_vector*0+1;
            end
            
            buffersignal = modulation .* - min(1,max(-1,1 * sin (signalfrequency(signal,channel)* (2 * pi * time_vector) ))) * amplitude(signal,channel) ;
            beginningpointsignal=floor(delay(signal,channel)*Fs)+1;
            
            buffer_one_signal(beginningpointsignal:beginningpointsignal+size(buffersignal,2)-1)=buffersignal;
            buffer_one_channel=buffer_one_channel+buffer_one_signal;
        end
        
        if initkeys==1
            noesc=keyinteraction({'Escape'},[],-1);%checks whether esc has been pressed
        end
        if ~isempty(noesc)
            buffer_one_channel=[];
            buffer_complete=[];
            ending=true;
            break
        end
    end
    if  ending~=true
        buffer_complete(:,channel)=buffer_one_channel;
    end
end
%buffer_complete
plot(buffer_complete)
sound(buffer_complete',44100);
time=GetSecs;
