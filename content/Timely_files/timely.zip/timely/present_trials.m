function ending=present_trials(parameters)



%create random order of trials
nb_SOA=length(parameters.SOA_to_test);
random_order_trial=randperm(nb_SOA);


%present trials
ending=false;
for trial=1:nb_SOA
    
    actual_trial=random_order_trial(trial);
    
    actual_SOA_to_test=parameters.SOA_to_test(actual_trial);
    if parameters.junksubject
        disp(['Trial:' int2str(trial) ' type:' int2str(actual_trial) ' asynchrony:' num2str(actual_SOA_to_test)])
    end
    
    
    TA =  max(0,actual_SOA_to_test);
    TV =  max(0,-actual_SOA_to_test);
    
    delay_to_use=[1 0; 0 1]*(rand(1)*.5+.2)+[TA 0; 0 TV] ;
    
    amplitude=[1 0; 0 1];
    actual_amplitude=amplitude.*repmat(parameters.amplitude,2,1);
    
    
    
    
    [ending,time]=beepit(parameters.frequency_of_stimulation,...
        delay_to_use,...
        parameters.duration_signal,...
        actual_amplitude,...
        max(max(delay_to_use))+.2+rand(1)*.2,...
        parameters.Fs, parameters.smoothing,0,1,0);
    
    
    
    [answer,rt]=keyinteraction({'leftarrow';'rightarrow'},time,1);
    
    if answer==0;ending=true; break; end
    
    
    
    
    if ending==true;
        break;
    else
        bytes = fprintf (parameters.datafile,['%s   %2i %3i    %2.3f     %2.3f %1i     \n'],...
            parameters.subject,...
            parameters.block, trial, ...
            actual_SOA_to_test,...
            rt, answer  );
    end%ending
end%trial

