function [e_mu, e_sigma]=probit_data_c(independent_variable,proportion_of_responces)
% Calculates the PSE and standard deviation of a psychometric curve. It
% first calculates the norm inv transform of the responce proportion and 
% fits them with a straight line.

%Usage:
% [PSE,JND]=probit_data_c(independent_variable,proportion_of_responces);
%  independent_variable:
%  proportion_of_responces: are two vectors with the same number of elements
%  mean_cumulative:         is the estimate of the mean of the underlying distribution
%
% independent_variable     =[-240 -200 -160 -120  -80  -40    0  40  80 120 160 200 240];
% proportion_of_responces  =[   0    0    0   .1   .5   .7   .8  .9   1   1   1   1  1 ];
%
% x=-200:1:200;y=normpdf(x,25,44);sy=cumsum(y);sy=sy/max(sy);plot(x,sy);[mu,sigma]=probit_data_c(x,sy)
%
% Created by Massimiliano Di Luca m.diluca@bham.ac.uk, Birmingham 24/7/2012

%makes input vectors to be all row vectors
independent_variable=reshape(independent_variable,1,max(size(independent_variable)));
proportion_of_responces=reshape(proportion_of_responces,1,max(size(proportion_of_responces)));

[independent_variable,order]=sort(independent_variable);
p=proportion_of_responces(order);

% get rid of extreme values
p=proportion_of_responces;
p(p==1)=1-1/10;
p(p==0)=1/10;

%calculates the inverse
np=norminv(p);
np(isinf(np))=nan;

%fit (can use robutsfit, but it takes more time)
line=regress(np',[independent_variable*0+1; independent_variable]');

e_mu=-line(1)/line(2);
e_sigma=1/line(2);