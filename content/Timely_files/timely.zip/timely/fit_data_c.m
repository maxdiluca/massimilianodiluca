function [e_mu, e_sigma]=fit_data_c(independent_variable,proportion_of_responses, number_of_responses)
% Fits a cumulative gaussian to a the proportion of responses
% obtained -for example- in a TOJ task using psignifit
%Usage:
% [e_mu, e_sigma]=fit_data_c(independent_variable,proportion_of_responses);
%
% inputs: two vectors with the same number of elements
%  - independent_variable     SOAs in ta TOJ task
%  - proportion_of_responses  proportion of responses for each SOA
%
% outputs: two values
%  - e_mu         estimate of the mean of the underlying distribution
%  - e_sigma      estimate of the standard deviation of the underlying distribution
%
% Examples:
% independent_variable     =[-240 -200 -160 -120  -80  -40    0  40  80 120 160 200 240];
% proportion_of_responses  =[   0    0    0   .1   .5   .7   .8  .9   1   1   1   1  1 ];
% number_of_responses  =[  10   10   10   10   10   10   10  10  10  10  10  10  10];
% [e_mu, e_sigma]=fit_data_c(independent_variable,proportion_of_responses, number_of_responses)
%
% >>e_mu =
%
%      -58.0758
%
%
% >>e_sigma =
%
%     147.5092
%
% mu=rand(1)*100-50;
% sigma=rand(1)*100+10;
% x=-200:50:200;
% sy=normcdf(x,mu,sigma);
% [e_mu,e_sigma]=mean_data_c(x,sy);
% clf
% hold on
% plot(x,sy,'.k');
% plot(mu,.5,'*r')
% plot(e_mu,.5,'ob')
% plot([mu mu+sigma],[.5 .84],'r')
% plot([mu e_mu+e_sigma],[.5 .84],'b')
% legend({'datapoint','real mu','estimated mu','real sigma','estimated sigma'})
%
% Created by Massimiliano Di Luca

%makes input vectors to be all row vectors
independent_variable=reshape(independent_variable,1,max(size(independent_variable)));
proportion_of_responses=reshape(proportion_of_responses,1,max(size(proportion_of_responses)));
number_of_responses=reshape(number_of_responses,1,max(size(proportion_of_responses)));

[independent_variable,order]=sort(independent_variable);
proportion_of_responses=proportion_of_responses(order);
number_of_responses=number_of_responses(order);

datafit=[independent_variable' proportion_of_responses'.*number_of_responses' number_of_responses'];

thisdirect=pwd;
direct=which('MapEstimate');
cd(direct(1:end-13))

priors.m_or_a = 'None';
priors.w_or_b = 'None';
priors.lambda = 'None';
priors.gamma  = 'None';

disp('Fitting...')
output=MapEstimate(datafit,priors,'sigmoid', 'gauss','nafc', 1,'cuts',[.25 .5 .75]);%'alpha_prior',' -gaussian -.03 .04','beta_limits',' 0.8 0.12');
cd(thisdirect);


e_mu=output.params_estimate(1);%output.thres(2);
e_sigma=output.thres(3)-output.thres(2);

