function [answer,rt]=keyinteraction(keysallowed,init,wait)
% [answer,&rt]=keyinteraction(keysallowed,&init,&wait)
%
% waits for a key to be pressed which correspoinds to a list of key given.
%
% input:
% keysallowed  list {'a';'b';'c'} with a description of keys that allow the function to return
%              to this list, ESC is also added
% init         time from which the delay of keypress is taken
% wait         the function can be used only tocheck wheter the keys are pressed or not or to wait for a key to be pressed
%                    1   the function waits for release of all keys before continuing
%                   -1   if you want to only check whether a key has been pressed but continuing execution (returns [] otherwise)
%                    0   if only the pressing is sufficient for the function to return
% 
% output:
% answer       either [], 0 or a number corresponding to the list of keys allowed
%              if ESC is press it returns answer=0
% rt           delay from a rt provided by the user as secon argument, or from call to function.
%
% example usage :
%
%answer=keyinteraction({'down';'right'},[],1) 
%2IFC & waiting for release
%
%answer=keyinteraction({'down';'right'},[],0) 
%2IFC & don't waiting for release
%
%[a,time] = KbCheck;
%[answer,rt]=keyinteraction({'down'},time,1)
%rt with 'down' key & waiting for release 
%
%keyinteraction({'space'},[],1);
%just waits for space
%
%keyinteraction({'esc'},[],-1);
%checks whether esc has been pressed. Returns 0 if it is, otherwise returns []
%
%29/01/2010 max
%18/05/2010 max found bug with wait=1; changed sum(vectorkeys(vectkeysallowed)) instead of sum(vectorkeys)

KbName('UnifyKeyNames');

if ~exist('init','var')
    [a,init,vectorkeys] = KbCheck;
elseif init==[]
    [a,init,vectorkeys] = KbCheck;
else
    [a,initk,vectorkeys] = KbCheck;
end

if ~exist('wait','var')
    wait=0;
end

time=0;

%check whether esc has been included by mistake
keysallowed(strcmp(keysallowed,'Escape'))=[];
keysallowed(strcmp(keysallowed,'Escape'))=[];
keysallowed(strcmp(keysallowed,'Escape'))=[];

vectkeysallowed=KbName(['Escape'; keysallowed]);

if wait~=-1
    disp(['waiting for key: ' reshape(char([keysallowed])',1,[]) ])
end
while sum(vectorkeys(vectkeysallowed))==0&&wait~=-1
    % pause(.001)%use for slow systems
    [a,time,vectorkeys] = KbCheck;
end

rt=(time-init);

answer=-1+find(vectorkeys(vectkeysallowed));

if ~isempty(answer)
    answer=answer(1);
    if answer>0
        disp([ char(keysallowed(answer)) ' has been pressed'])
    elseif wait~=-1
        disp('ESC has been pressed')
    end
end
%wait untill all keys are released

if wait==1
    disp('waiting for key release')
    while sum(vectorkeys(vectkeysallowed))>0
        [a,b,vectorkeys] = KbCheck;
    end
    disp('all keys have been released')
end
