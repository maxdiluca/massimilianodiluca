%Audiovisual simultaneity judgment experiment with AV device attached to 2 channels
%audiocard: left (white) sound, right (red) light

clear all
close all
fclose all

clc

% RandStream.setDefaultStream ...
%    (RandStream('mt19937ar','seed',sum(100*clock)));

parameters.Fs=44100;  



subject=input('CLICK HERE and enter subject''s first name ','s');

if size(subject,2)<4
    subject=[subject '------'];
end

parameters.subject=datestr(now,30);
if ismac
    subject_name=['./data/' parameters.subject '_' subject(1:4) '_dat_t.txt'];
else
    subject_name=['.\data\' parameters.subject '_' subject(1:4) '_dat_t.txt'];
end
datafile = fopen(subject_name, 'wt');
parameters.datafile=datafile;
if or((subject(1:4)=='junk'),(subject(1:4)=='----'))
    parameters.junksubject=true;
else
    parameters.junksubject=false;
end
ending=false;

%set variables for course of experiment
SOA_to_test=[0 20 90 170 250 350]/1000;
parameters.SOA_to_test=unique([SOA_to_test -SOA_to_test]);
parameters.n_SOA_to_test=length(SOA_to_test);%positive values mean light is presented first 

%set various basic variables for the whole experiment
parameters.frequency_of_stimulation=[100 1000];
parameters.duration_signal=.20;
parameters.amplitude=[1 .1];
parameters.smoothing=.001;
parameters.ISI=1;
parameters.max_delay_used=max(SOA_to_test);


if parameters.junksubject==false
    disp('Use arrow keys to answer which stimulus came first')
    disp('Left arrow: Sound first')
    disp('Right arrow: Light first')
    disp('')
    disp('Turn off monitor and press spacebar')
    
    [answer,rt]=keyinteraction({'space'},[],1);
    pause(2)
end

for block=1:parameters.test_repetitions
    parameters.block=block;
    ending=present_trials(parameters);
    if ending==true; break; end
end


fclose (datafile);
fclose all
Screen('Closeall');
FlushEvents('keyDown');
FlushEvents('update');
PsychPortAudio('Close');

if (~parameters.junksubject)&&(~ending); 
    disp('** thank you for your participation **'); 
    disp('press spacebar'); 
end
