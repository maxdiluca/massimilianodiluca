% before correction A A A VA and V V V AV : SOA<0
% before correction V V V AV SOA<0
% after correction A A A VA datafit(1) >0
% after correction V V V VA datafit(1) >0
% Graphs :   AV ___ S ___ VA


%Analysis for the long experiment TOJ - many trials.

% analysis temporal information. Calculates PSS before and after adaptation
% to a delay between modalities
% Uses psignifit
%
clear all
clc
close all

stimulus_appearing_first_with_positive_soa=1;

directory='./data';

filenames={
    'tJIL'
    'Edd-'
    'DAR1'
    '01--'
    'tann'
   % 'mg--'
    'teug'
    'T_DE'
    'satz'
    'tsn2'
    'Nik-'
    'AD--'
    'tsn-'
  %  'tesp'
    'Tbar'
   % 'tgio'
    'SS--'
    'tkkk'
  %  'tjjj'
  %  'tika'
    }

fit=1;

subjectstoanalyze=1:size(filenames,1);
thisdirect=pwd;

h1=figure(10);
stats=[];
statsj=[];

subjectcounter=0;
for subject=subjectstoanalyze
    figure(h1);
    subjectcounter=subjectcounter+1;
    
    datarawa=[];
    fils=dir([directory '/*'  char(filenames(subject))  '*_dat_t.txt']);
    
    
    try
        for n=1:size(fils,1)
            disp(['Trying: ' directory '/' fils(n).name])
            fid=fopen([directory '/' fils(n).name],'r');
            
            frewind(fid)
            disp(['Extracting data...']);
            [datarawp nc] = fscanf(fid,['%*s  %i %i   %f      %f %i  '],[5, inf] );
            
            
            
            
            
            
            
            
            col_trial=1;
            col_pair=2;
            
            col_soa=3;
            col_rt=4;
            col_resp=5;
            
            
            
            
            
            fclose(fid)  ;
            datarawa=[datarawa; datarawp'];
        end
    catch
        fclose all
        lasterr
        disp(['File for subject '  char(filenames(subject))  ' does not exist or is not conform ...'])
    end
    
    dataraw=datarawa;
    
    
    maxvi=max(.15,max(abs(dataraw(:,col_soa))));%maximum soa to plot
    soa_tested=(unique(dataraw(:,col_soa))');
    
    figure(1)
    
    counter=0;
    datafito=[0 0];
    datafit0=0;
    
    soacounter=1;
    
    for soa=soa_tested
        data_binned_soa=dataraw(dataraw(:,col_soa)==soa,:);
        
        trials=size(data_binned_soa,1);
        yes=mean(data_binned_soa(:,col_resp)~=stimulus_appearing_first_with_positive_soa);
        
        datafit(soacounter,:)=[soa yes trials];
        
        
        soacounter=soacounter+1;
    end
    datafit=sortrows(datafit,1);
    
    propp(subject,:)=datafit(:,2);
    
    hold on
    
    counter=counter+1;
    subplot(ceil(sqrt(max(subjectstoanalyze))),ceil(sqrt(max(subjectstoanalyze))),find(subject==subjectstoanalyze))
    plot(datafit(:,1),datafit(:,2))
    axis([-.25 .25 0 1])
    
    
    switch fit
        
        
        case 1 %spearman karber
            
            [uEst,varEst] = mean_data_c(datafit(:,1),datafit(:,2));
             pss(subject)=uEst;
    jnd(subject)=varEst;       
            
        case 2 %probit
            
            [uEst,varEst] = probit_data_c(datafit(:,1),datafit(:,2));
           pss(subject)=uEst;
    jnd(subject)=varEst/sqrt(2);   
            
        case 3 %psignifit
            
            
            [uEst,varEst] = fit_data_c(datafit(:,1),datafit(:,2),datafit(:,3));
         pss(subject)=uEst;
    jnd(subject)=varEst;     
            
    end
  
    
    
    
end

figure
plot(datafit(:,1),mean(propp))

figure
subplot(2,3,1)
plot(pss,'*k')
hold on
plot(find(pss>maxvi),(find(pss>maxvi)>0)*maxvi,'*r')
plot(find(pss<-maxvi),(find(pss<-maxvi)>0)*-maxvi,'*r')
steplot(0,pss')
maxis=axis;
axis([-.5 maxis(2) max(maxis(3)-.01,-maxvi) min(maxis(4)+.01,maxvi)])
title('individual pss values')

subplot(2,3,2)
hist(pss)
hold on
title('distribution of pss values')

subplot(2,3,4)
plot(jnd,'*k')
hold on
steplot(0,jnd')
plot(find(jnd>maxvi),(find(jnd>maxvi)>0)*maxvi,'*r')
plot(find(jnd<0),(find(jnd<0)>0)*0,'*r')
maxis=axis;
axis([-.5 maxis(2) 0 min(maxis(4)+.01,maxvi)])
title('individual jnd values')

subplot(2,3,5)
hist(jnd)
hold on
title('distribution of jnd values')

subplot(2,3,6)
plot(pss,jnd,'.')
hold on
plot([-maxvi -maxvi maxvi maxvi -maxvi ], [0 maxvi maxvi 0 0])
hold on
title('individual pss and jnd values')
