---
title: Publications

# View.
#   1 = List
#   2 = Compact
#   3 = Card
#   4 = Citation
view: 3

# Optional header image (relative to `static/media/` folder).
header:
  caption: ""
  image: ""
---


https://scholar.google.com/citations?hl=en&user=93hi3QcAAAAJ

https://www.scopus.com/authid/detail.uri?authorId=7004587933
