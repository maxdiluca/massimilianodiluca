%       demo of fiio amplifier and testing device with LED and speaker
%shows 5 SOAs and requests space to continue after each of them
%turn up the volume all the way and turn on the amplifier (blue light)
%    
%m.diluca@bham.ac.uk        12/2/2013

clear all
Fs=44100;
duration=.2;    
    
delay =repmat(([1 2 3 4 5 6]*.7)',1,2);

frequency= repmat([3000 200],size(delay,1),1);

  clc;disp('visual sequence isochronous next');keyinteraction({'space'},[],1);
     

  
  
  
  
  
  
  
  
  
  
  

aplitude = repmat([0         1 ],size(delay,1),1);
beepit(frequency,delay,duration,aplitude,5,Fs,.01);    


clc;
disp('audio sequence isochronous next');keyinteraction({'space'},[],1);

aplitude = repmat([1            0 ],size(delay,1),1);

beepit(frequency,delay,duration,aplitude,5,Fs,.01);    




clc;
disp('audio sequence last beat early  next');keyinteraction({'space'},[],1);



delay =repmat(([1 1.4 3.8 4.3 5.2 5.8]*.7)',1,2);
aplitude = repmat([1           0 ],size(delay,1),1);
beepit(frequency,delay,duration,aplitude,5,Fs,.01);    


clc;
disp('audio sequence last beat late  next');keyinteraction({'space'},[],1);



delay =repmat(([1 2 3 4 5 6.2]*.7)',1,2);
aplitude = repmat([1           0 ],size(delay,1),1);
beepit(frequency,delay,duration,aplitude,5,Fs,.01);    




clc;
disp('TASK sequence on the 6th beat');keyinteraction({'space'},[],1);






delay =repmat(([1 2 3 4 5 6.2]*.7)',1,2);
delay(end,end)=delay(end,end)+.2;
aplitude = repmat([1           0 ],size(delay,1),1);
aplitude(end,end)=1;
beepit(frequency,delay,duration,aplitude,5,Fs,.01);    















clc;disp('demo ended')