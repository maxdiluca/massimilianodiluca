clear all
close all
clc

load result_sk
psss=pss
jnds=jnd
load result_probit
jndp=jnd
pssp=pss
load result_fit
jndf=jnd
pssf=pss

clear pss jnd


limitjndrejection=9999.35

participantstoreject=unique([find(jnds>limitjndrejection),find(jndp>limitjndrejection),find(jndf>limitjndrejection)]);

psss(participantstoreject)=[];
pssp(participantstoreject)=[];
pssf(participantstoreject)=[];
jnds(participantstoreject)=[];
jndp(participantstoreject)=[];
jndf(participantstoreject)=[];


psslim=max([max(abs(pssf)),max(abs(pssp)),max(abs(psss))]);
jndlim=max([max(abs(jndf)),max(abs(jndp)),max(abs(jnds))]);


%stem3(psss,pssp,pssf)

figure
subplot(2,4,1)
plot(psss,pssp,'.')
a=robustfit(psss,pssp);
hold on
plot([-psslim psslim],[-psslim psslim]*a(2)+a(1),'r')
xlabel('pss s-k');ylabel('pss probit')


axis([-psslim psslim -psslim psslim])
axis equal

subplot(2,4,2)
plot(psss,pssf,'.')
a=robustfit(psss,pssf);
hold on
plot([-psslim psslim],[-psslim psslim]*a(2)+a(1),'r')
xlabel('pss s-k');ylabel('pss fit')
axis([-psslim psslim -psslim psslim])
axis equal

subplot(2,4,3)
plot(pssp,pssf,'.')
a=robustfit(pssp,pssf);
hold on
plot([-psslim psslim],[-psslim psslim]*a(2)+a(1),'r')
xlabel('pss probit');ylabel('pss fit')
axis([-psslim psslim -psslim psslim])
axis equal

subplot(2,4,4)
steplot(1,pssp')
hold on
steplot(2,psss')
steplot(3,pssf')
axis([.5 3.5 -.15 .15])

subplot(2,4,5)
plot(jnds,jndp,'.')
a=robustfit(jnds,jndp);
hold on
plot([-jndlim jndlim],[-jndlim jndlim]*a(2)+a(1),'r')
xlabel('jnd s-k');ylabel('jnd probit')
axis([-jndlim jndlim -jndlim jndlim])
axis equal


subplot(2,4,6)
plot(jnds,jndf,'.')
a=robustfit(jnds,jndf);
hold on
plot([-jndlim jndlim],[-jndlim jndlim]*a(2)+a(1),'r')
xlabel('jnd s-k');ylabel('jnd fit')
axis([-jndlim jndlim -jndlim jndlim])
axis equal

subplot(2,4,7)
plot(jndp,jndf,'.')
a=robustfit(jndp,jndf);
hold on
plot([-jndlim jndlim],[-jndlim jndlim]*a(2)+a(1),'r')
xlabel('jnd probit');ylabel('jnd fit')
axis([-jndlim jndlim -jndlim jndlim])
axis equal


subplot(2,4,8)
steplot(1,jndp')
hold on
steplot(2,jnds')
steplot(3,jndf')
axis([.5 3.5 .05 .35])
